

from NanoKontrolShift import NanoKontrolShift

def create_instance(c_instance):
    """ Creates and returns the NanoKontrolShift script """
    return NanoKontrolShift(c_instance)
